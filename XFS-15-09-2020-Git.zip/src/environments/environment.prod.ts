export const environment = {
  production: true,
  firebase: {
    apiKey: 'YOUR_API_KEY',
    authDomain: 'pwa-talk-meetup.firebaseapp.com',
    databaseURL: 'https://pwa-talk-meetup.firebaseio.com',
    projectId: 'pwa-talk-meetup',
    storageBucket: 'pwa-talk-meetup.appspot.com',
    messagingSenderId: 'YOUR_SENDER_ID'
  },
  dataFileUrl : '/XFS-PWA'
};
