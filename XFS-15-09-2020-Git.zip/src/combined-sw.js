importScripts('ngsw-worker.js');
importScripts('firebase-messaging-sw.js');
