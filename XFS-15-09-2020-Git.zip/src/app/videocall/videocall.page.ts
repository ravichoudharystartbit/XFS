import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-videocall',
  templateUrl: './videocall.page.html',
  styleUrls: ['./videocall.page.scss'],
})
export class VideocallPage implements OnInit {


  constructor(
  ) {

  }

  ngOnInit() {
  }

}
